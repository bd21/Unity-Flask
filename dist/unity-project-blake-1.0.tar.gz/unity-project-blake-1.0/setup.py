from distutils.core import setup

setup(
    name='unity-project-blake',
    version='1.0',
    packages=['./',],
    url='github.com/bd21/unity-project',
    license='MIT',
    author='Blake Denniston',
    author_email='bd21@uw.edu',
    description='Unity Interview Project'
)
